# 2024FullStackQap2
This is a second repo for quantitative assessment practice in FullStack
